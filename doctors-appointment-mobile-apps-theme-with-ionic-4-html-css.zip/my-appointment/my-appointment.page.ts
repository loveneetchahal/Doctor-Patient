import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-appointment',
  templateUrl: './my-appointment.page.html',
  styleUrls: ['./my-appointment.page.scss'],
})
export class MyAppointmentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
