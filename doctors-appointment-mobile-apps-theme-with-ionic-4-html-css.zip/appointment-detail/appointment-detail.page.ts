import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-detail',
  templateUrl: './appointment-detail.page.html',
  styleUrls: ['./appointment-detail.page.scss'],
})
export class AppointmentDetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
