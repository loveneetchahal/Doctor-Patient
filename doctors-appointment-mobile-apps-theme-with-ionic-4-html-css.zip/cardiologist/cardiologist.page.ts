import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cardiologist',
  templateUrl: './cardiologist.page.html',
  styleUrls: ['./cardiologist.page.scss'],
})
export class CardiologistPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
