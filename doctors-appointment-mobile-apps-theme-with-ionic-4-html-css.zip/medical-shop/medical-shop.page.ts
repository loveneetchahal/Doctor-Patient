import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medical-shop',
  templateUrl: './medical-shop.page.html',
  styleUrls: ['./medical-shop.page.scss'],
})
export class MedicalShopPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
