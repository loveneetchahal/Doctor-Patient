import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab-test',
  templateUrl: './lab-test.page.html',
  styleUrls: ['./lab-test.page.scss'],
})
export class LabTestPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
