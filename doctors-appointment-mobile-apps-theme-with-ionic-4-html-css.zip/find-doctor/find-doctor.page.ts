import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-find-doctor',
  templateUrl: './find-doctor.page.html',
  styleUrls: ['./find-doctor.page.scss'],
})
export class FindDoctorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
