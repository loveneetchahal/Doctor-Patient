import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-schedule',
  templateUrl: './appointment-schedule.page.html',
  styleUrls: ['./appointment-schedule.page.scss'],
})
export class AppointmentSchedulePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
