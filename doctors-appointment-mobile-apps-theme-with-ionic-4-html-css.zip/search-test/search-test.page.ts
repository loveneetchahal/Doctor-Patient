import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-test',
  templateUrl: './search-test.page.html',
  styleUrls: ['./search-test.page.scss'],
})
export class SearchTestPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
