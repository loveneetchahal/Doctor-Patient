import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab-info',
  templateUrl: './lab-info.page.html',
  styleUrls: ['./lab-info.page.scss'],
})
export class LabInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
